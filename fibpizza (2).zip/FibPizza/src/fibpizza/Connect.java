package fibpizza;
import java.sql.*;


//Created by : Ashley George 
//Establish Connection with MS Access to Connect.java
public class Connect {
    //Create your variables 
    Connection conn;
    ResultSet rs;
    Statement st;
    
    public Connect(){
        //Use a try/catch to catch any SQL Exceptions
        try{
           conn = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Ashley George\\Documents\\HumanR.accdb");
           st = conn.createStatement();
           rs = st.executeQuery("SELECT * FROM Employee");
           
           while(rs.next()){
               System.out.println("ID"+"\t" +"Name of Employee"+"\t"+ "AccountID"+ "\t"+"Phone Number" +"\t"+"Job Title" );
              
               System.out.println(rs.getInt(1)+ "\t"+ rs.getString(2)+"\t" + rs.getString(3)+ "\t"+ rs.getString(4) +"\t"+ rs.getString(5));
                System.out.println();
           }
        }
        catch(SQLException e){
            System.out.println(e);
        }
      
    }
   
}